Copyright (c) 2002-2008 MTUX All rights reserved.

FREEWARE Software License Agreement (My Mobile - MyMobiler)
--------------------------------------------------------------------------------------

This is our Freeware Software License Agreement, which applies to all software products available for download from MTUX website(s), unless labeled as something other than freeware. All software available for download via the MTUX website(s) are copyright MTUX unless otherwise stated. Copyright law protects this software program and any associated material. MTUX retains title to and ownership in the copyright of the software program and the associated materials. 

Freeware License Rights:
All software products available for download from associated website(s), unless labeled otherwise, are provided as freeware. Freeware products are provided are provided free of charge. Occasionally the copyright holder may post a request for a donation in support of this software. This type of request does not change the classification of this software as freeware. Freeware software may be used as many times as you like, for as long as you like. You may copy and distribute copies of this program provided that you keep this copyright notice and disclaimer of warranty intact. You must not charge money or fees for the software product to anyone except to cover distribution costs. The copyright holder reserves the right to reclassify this software as a non-freeware product at a later date (i.e. shareware of public domain). Doing so will not modify the license agreement of previously distributed executables. 

Warranty:
This program is provided "as is" without warranties of any kind, either expressed or implied, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose. The entire risk as to the quality and performance of the program is with you. Should the program prove defective, you assume the cost of all necessary servicing, repair or correction. In no event will any copyright holder be liable to you for damages, including any general, special, incidental or consequential damages arising out of the use or inability to use the program (including but not limited to loss of data or data being rendered inaccurate or losses sustained by you or third parties or a failure of the program to operate with any other programs). 

Technical Support:
Technical support may be provided via e-mail and/or website postings. While every effort is made to provided timely technical support no guarantees whatsoever are implied that technical support will be provided or that technical support, when provided, will be accurate. Software offered on this site is basically unsupported and supplied on an as-is basis. 

Agreement:
By using our software products you are automatically agreeing to and show that you have read and understood the terms and conditions contained within this Freeware Software License Agreement. This Freeware Software License Agreement is then effective while you use and continue to make use of these software products. If you do not agree with our Freeware Software License Agreement you must not use our software products - this Freeware Software License Agreement will then not apply to you. This Freeware Software License Agreement is subject to change without notice. 

Any company names, logos, mottoes and product names mentioned or shown on associated website(s) or in software products may be copyright, trademarked or registered trademarked by their respective owners

Copyright (c) 2002-2008 MTUX All rights reserved.
