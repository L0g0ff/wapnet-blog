/*-------------------------------------------------------------

installer.c -- simple menu for WiiSCU
(c) Wack0 2009
Portions (c) tona 2008

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any
damages arising from the use of this software.
 
Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and
redistribute it freely, subject to the following restrictions:
 
1.The origin of this software must not be misrepresented; you
must not claim that you wrote the original software. If you use
this software in a product, an acknowledgment in the product
documentation would be appreciated but is not required.
 
2.Altered source versions must be plainly marked as such, and
must not be misrepresented as being the original software.
 
3.This notice may not be removed or altered from any source
distribution.
 
-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <gccore.h>
#include <wiiuse/wpad.h>

#include "wiibasics.h"
#include "patchmii_core.h"
#include "sysconf.h"

#define ITEMS 	12
// #define DEBUG
#define VERSION "0.21"
#define WARNING_SIGN "\x1b[30;1m\x1b[43;1m/!\\\x1b[37;1m\x1b[40m"

int ret = 0;
int ios16 = 0;
int ios38 = 0;
int ios60 = 0;
int ios61 = 0;
int newschan = 0;
int weatherchan = 0;
int miichan = 0;
int photochan = 0;
int shopchan = 0;

u32 selected = 0;
char page_contents[ITEMS][64];

void updateSelected(int delta){
	if (selected + delta >= ITEMS || selected + delta < 0) return;
	
	if (delta != 0){
		// Remove the cursor from the last selected item
		page_contents[selected][2] = ' ';
		page_contents[selected][45] = ' ';
		page_contents[selected][57] = ' ';
		// Set new cursor location
		selected += delta;
	}
	
	// Add the cursor to the now-selected item
	page_contents[selected][2] = '>';
	page_contents[selected][45] = '<';
	page_contents[selected][57] = '>';
}

void updatePage(void){
	
	if (ios16 == 0) {
		sprintf(page_contents[0], "    %-40s   %10s  \n", "Install IOS16 ?", "No     ");
	}
	else if (ios16 == 1) {
		sprintf(page_contents[0], "    %-40s   %10s  \n", "Install IOS16 ?", "-Trucha");
	}
	else if (ios16 == 2) {
		sprintf(page_contents[0], "    %-40s   %10s  \n", "Install IOS16 ?", "+Trucha");
	}
	if (ios38 == 0) {
		sprintf(page_contents[1], "    %-40s   %10s  \n", "Install IOS38 ?", "No     ");
	}
	else if (ios38 == 1) {
		sprintf(page_contents[1], "    %-40s   %10s  \n", "Install IOS38 ?", "-Trucha");
	}
	else if (ios38 == 2) {
		sprintf(page_contents[1], "    %-40s   %10s  \n", "Install IOS38 ?", "+Trucha");
	}
	if (ios60 == 0) {
		sprintf(page_contents[2], "    %-40s   %10s  \n", "Install IOS60 ?", "No     ");
	}
	else if (ios60 == 1) {
		sprintf(page_contents[2], "    %-40s   %10s  \n", "Install IOS60 ?", "-Trucha");
	}
	else if (ios60 == 2) {
		sprintf(page_contents[2], "    %-40s   %10s  \n", "Install IOS60 ?", "+Trucha");
	}
	if (ios61 == 0) {
		sprintf(page_contents[3], "    %-40s   %10s  \n", "Install IOS61 ?", "No     ");
	}
	else if (ios61 == 1) {
		sprintf(page_contents[3], "    %-40s   %10s  \n", "Install IOS61 ?", "-Trucha");
	}
	else if (ios61 == 2) {
		sprintf(page_contents[3], "    %-40s   %10s  \n", "Install IOS61 ?", "+Trucha");
	}
	if (newschan == 0) {
		sprintf(page_contents[4], "    %-40s   %10s  \n", "Update the News Channel ?", "No     ");
	}
	else if (newschan == 1) {
		sprintf(page_contents[4], "    %-40s   %10s  \n", "Update the News Channel ?", "Yes    ");
	}
	if (weatherchan == 0) {
		sprintf(page_contents[5], "    %-40s   %10s  \n", "Update the Weather Channel ?", "No     ");
	}
	else if (weatherchan == 1) {
		sprintf(page_contents[5], "    %-40s   %10s  \n", "Update the Weather Channel ?", "Yes    ");
	}
	if (miichan == 0) {
		sprintf(page_contents[6], "    %-40s   %10s  \n", "Update the Mii Channel ?", "No     ");
	}
	else if (miichan == 1) {
		sprintf(page_contents[6], "    %-40s   %10s  \n", "Update the Mii Channel ?", "Yes    ");
	}
	if (photochan == 0) {
		sprintf(page_contents[7], "    %-40s   %10s  \n", "Update the Photo Channel ?", "No     ");
	}
	else if (photochan == 1) {
		sprintf(page_contents[7], "    %-40s   %10s  \n", "Update the Photo Channel ?", "Yes    ");
	}
	if (shopchan == 0) {
		sprintf(page_contents[8], "    %-40s   %10s  \n", "Update the Wii Shop Channel ?", "No     ");
	}
	else if (shopchan == 1) {
		sprintf(page_contents[8], "    %-40s   %10s  \n", "Update the Wii Shop Channel ?", "Yes    ");
	}
	sprintf(page_contents[9], "    %-40s   %10s  \n", "Install/Update All Selected", "Go     ");
	sprintf(page_contents[10], "    %-40s   %10s  \n", "Exit to Homebrew Channel", "Exit    ");
	sprintf(page_contents[11], "    %-40s   %10s  \n", "Reboot to System Menu", "Reboot  ");

	updateSelected(0);
}

//---------------------------------------------------------------------------------
int main(int argc, char **argv) {
//---------------------------------------------------------------------------------
    
	//ret = IOS_ReloadIOS(35);
	int i = 0;
	int reg;
	u32 buttons;
	basicInit();
	WPAD_Init();
	printf("\x1b[2J\n\n");
	#ifdef DEBUG
	printf("going into patchmii control\n");
	#endif
	patchmii_network_init();
	printf("[*] Finding channel regions ");
	#ifdef DEBUG
	printf("\nInit SYSCONF ..");
	#endif
	ret = SYSCONF_Init();
	if (ret < 0) {
		printf("failed ! (SYSCONF_Init(); returned %d)", ret);
		wait_anyKey();
		exit(1);
	}
	#ifdef DEBUG
	printf("Done !\nGetting SYSCONF Game Region ..");
	#else
	printf(".");
	#endif
	reg = SYSCONF_GetRegion();
	if (reg < 0) {
		printf("failed ! (SYSCONF_GetRegion(); returned %d)", reg);
		wait_anyKey();
		exit(1);
	}
	#ifdef DEBUG
	printf("Done !\nChecking region parsed ..");
	#else
	printf(".");
	#endif
	if (reg != 0 && reg != 1 && reg != 2 && reg != 3) {
		printf("failed ! (Can't see game region, corrupt SYSCONF ?)");
		wait_anyKey();
		exit(1);
	}
	#ifdef DEBUG
	printf("Done !");
	#else
	printf(".succeeded !\n");
	#endif
	printf("\x1b[2J\n\n");
	#ifdef DEBUG
	printf("\n\t\t\t\t\t\t   WiiSCU v%s-debug\n", VERSION);
	#else
	printf("\n\t\t\t\t\t\t   WiiSCU v%s\n", VERSION);
	#endif
	printf("\n\t  This software comes supplied with absolutely no warranty.\n");
	printf("\t\t\t\tUse this software at your own risk.\n");
	printf("\t\t(read: if you brick your wii, don't come crying to me.)\n\n\n");
	printf(WARNING_SIGN " PLEASE READ IF YOU DON'T WANT DUPE WEATHER/NEWS CHANNELS " WARNING_SIGN "\n\n");
	if (reg == 0) {
		printf("\tI have determined that your Wii runs JAPANESE channels.\n\n");
	}
	else if (reg == 1) {
		printf("\tI have determined that your Wii runs NTSC-U channels.\n\n");
	}
	else if (reg == 2) {
		printf("\tI have determined that your Wii runs PAL channels.\n\n");
	}
	else if (reg == 3) {
		printf("\tI have determined that your Wii runs KOREAN channels.\n\n");
	}
	printf("\tIf this information is incorrect, your SYSCONF may be corrupt,\n");
	printf("\tor you need to change your GAME REGION in AnyRegionChanger.\n\n");
	printf("\tI will use this information to install your region\n\tweather/news channel.\n");
	printf("\n\n\n");
	sleep(5);
	printf("\n\n\t\t\t  Press (1) to continue or HOME to exit.\n");
	wait_key(WPAD_BUTTON_1);
	
	updatePage();
	
	main_loop:
	printf("\x1b[2J\n");
	#ifdef DEBUG
	printf("WiiSCU v%s-debug (c) 2009 Wack0\n", VERSION);
	#else
	printf("WiiSCU v%s (c) 2009 Wack0\n", VERSION);
	#endif
	printf("Portions (c) 2008 tona - Portions (c) 2008 bushing\n");
	printf("PatchMii_core net_init() retry code (c) 2009 kerframil\n");
	printf("---------------------------------------------------------------\n");
	printf("IOS Installation/Upgrade Options\n");
	printf("---------------------------------------------------------------\n");
	for (i = 0; i < 4; i++)
	printf(page_contents[i]);
	printf("---------------------------------------------------------------\n");
	printf("System Channels Upgrade Options\n");
	printf("---------------------------------------------------------------\n");
	for (i = i; i < 9; i++)
	printf(page_contents[i]);
	printf("---------------------------------------------------------------\n");
	for (i = i; i < ITEMS; i++)
		printf(page_contents[i]);
	printf("---------------------------------------------------------------\n");
	
	
	
	buttons = wait_anyKey();
	
	if (buttons & WPAD_BUTTON_DOWN)
		updateSelected(1);
	
	if (buttons & WPAD_BUTTON_UP)
		updateSelected(-1);
	
	if (buttons & WPAD_BUTTON_LEFT){
		switch(selected){
			case 0:
				if (--ios16 < 0) ios16 = 2;
			break;
			case 1:
				if (--ios38 < 0) ios38 = 2;
			break;
			case 2:
				if (--ios60 < 0) ios60 = 2;
			break;
			case 3:
				if (--ios61 < 0) ios61 = 2;
			break;
			case 4:
				if (--newschan < 0) newschan = 1;
			break;
			case 5:
				if (--weatherchan < 0) weatherchan = 1;
			break;
			case 6:
				if (--miichan < 0) miichan = 1;
			break;
			case 7:
				if (--photochan < 0) photochan = 1;
			break;
			case 8:
				if (--shopchan < 0) shopchan = 1;
			break;
		}
	}
	
	if (buttons & WPAD_BUTTON_RIGHT){
		switch(selected){
			case 0:
				if (++ios16 == 3) ios16 = 0;
			break;
			case 1:
				if (++ios38 == 3) ios38 = 0;
			break;
			case 2:
				if (++ios60 == 3) ios60 = 0;
			break;
			case 3:
				if (++ios61 == 3) ios61 = 0;
			break;
			case 4:
				if (++newschan == 2) newschan = 0;
			break;
			case 5:
				if (++weatherchan == 2) weatherchan = 0;
			break;
			case 6:
				if (++miichan == 2) miichan = 0;
			break;
			case 7:
				if (++photochan == 2) photochan = 0;
			break;
			case 8:
				if (++shopchan == 2) shopchan = 0;
			break;
		}
	}
	
	if (buttons & WPAD_BUTTON_A){
		switch(selected){
			case 9:
				printf("[*] Are you sure you wish to install/update selected ?\n");
				if (yes_or_no()) {
					//time to do this thing
					//ios16
					if (ios16 == 1) {
						printf("[*] Installing IOS16 without trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,16,0,1,16,0,0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					if (ios16 == 2) {
						printf("[*] Installing IOS16 with trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,16,0,1,16,0,1);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					//ios38
					if (ios38 == 1) {
						printf("[*] Installing IOS38 without trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,38,0,1,38,0,0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					if (ios38 == 2) {
						printf("[*] Installing IOS38 with trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,38,0,1,38,0,1);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					//ios60
					if (ios60 == 1) {
						printf("[*] Installing IOS60 without trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,60,6174,1,60,6174,0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					if (ios60 == 2) {
						printf("[*] Installing IOS60 with trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,60,6174,1,60,6174,1);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					//ios61
					if (ios61 == 1) {
						printf("[*] Installing IOS61 without trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,61,0,1,61,0,0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					if (ios61 == 2) {
						printf("[*] Installing IOS61 with trucha bug ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(1,61,0,1,61,0,1);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					//news channel
					if (newschan == 1) {
						printf("[*] Installing the News Channel ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002, 0x48414741, 0, 0x10002, 0x48414741, 0, 0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
						if (reg == 0) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x4841474a,0,0x10002,0x4841474a,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
						if (reg == 1) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x48414745,0,0x10002,0x48414745,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
						if (reg == 2) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x48414750,0,0x10002,0x48414750,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
						if (reg == 3) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x4841474b,0,0x10002,0x4841474b,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
					}
					//weather channel
					if (weatherchan == 1) {
						printf("[*] Installing the Weather Channel ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002, 0x48414641, 0, 0x10002, 0x48414641, 0, 0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
						if (reg == 0) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x4841464a,0,0x10002,0x4841464a,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
						if (reg == 1) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x48414645,0,0x10002,0x48414645,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
						if (reg == 2) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x48414650,0,0x10002,0x48414650,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
						if (reg == 3) {
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002,0x4841464b,0,0x10002,0x4841464b,0,0);
							if (ret < 0) {
								printf("[-] PatchMii_install(); returned %d", ret);
								printf("[*] Press any key to quit.\n");
								wait_anyKey();
								exit(1);
							}
						}
					}
					//mii channel
					if (miichan == 1) {
						printf("[*] Installing the Mii Channel ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002, 0x48414341, 0, 0x10002, 0x48414341, 0, 0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					//photo channel
					if (photochan == 1) {
						printf("[*] Installing the Photo Channel ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002, 0x48415941, 0, 0x10002, 0x48415941, 0, 0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
					//wii shop channel
					if (shopchan == 1) {
						printf("[*] Installing the Wii Shop Channel ..\n");
						#ifdef DEBUG
						printf("going into patchmii control\n");
						#endif
						ret = patchmii_install(0x10002, 0x48414241, 0, 0x10002, 0x48414241, 0, 0);
						if (ret < 0) {
							printf("[-] PatchMii_install(); returned %d", ret);
							printf("[*] Press any key to quit.\n");
							wait_anyKey();
							exit(1);
						}
					}
				}
			break;
			case 10:
				exit(0);
			break;
			case 11:
				miscDeInit();
				STM_RebootSystem();
			break;
		}
	}
	updatePage();
	goto main_loop;
}
