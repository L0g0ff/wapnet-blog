
*******************************************************
*
*     My Mobile (MyMobiler ver 1.2)  by MTUX
*
*     Contact: info@mtux.com, http://www.mtux.com
*
*******************************************************

-------------------------------
    1. Install  & Launch 'MyMobile'
-------------------------------
	
1. Download 'MyMobile10.exe' and run installation program.

2. Connect with ActiveSync 

3. Run "MyMobiler" on '(Desktop)\My Mobile'

4. Go to menu, Tray Menu - Connect
    - It will install remote.exe to your device automatically.
    - Please uninstall first on your device if you've installed before.

5. Go to menu, Tray Menu - Open Mobiler
    - Popup mobile screen 

-------------------------------
* ZIP file Installation

1. Download 'MyMobile12.zip'

2. Create folder and extract all files. (ex: Create "\MyMobile" folder and extract files)

3. Run "MyMobiler"

* You don't have to install to your mobile device. It will be installed automatically. 
  In case of you want to install manually, copy "remote.exe" file to your mobile "(Mobile)\Windows".
   
1. (WM 2003 device) Rename "rm2003.ex_" to "remote.exe" 
    (WM 5.0 or WM 6.0 device) Rename "rm2005.ex_" to "remote.exe" 
2. Copy "remote.exe" to your mobile windows folder. "(Mobile)\Windows"

-------------------------------
   2. Uninstall 'MyMobile'
-------------------------------

1. Uncheck "Auto Connect"  (Tray Menu - Auto Connect)

2. Uninstall ( Tray Menu - Configure Mobile - Uninstall)

       - This may take a couple of seconds.
       - If error occurs, 'Quit Remote' and try again.
       - Or you can delete below files manually.
          1. \Windows\Remote.exe
          2. \Windows\Start Menu\Programs\My Mobiler.lnk

3. Delete "My Mobile" folder On your desktop. 
 

Thank you,
