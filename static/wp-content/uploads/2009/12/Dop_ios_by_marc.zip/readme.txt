--------------------
 Dop-IOS v8 by Marc
--------------------
NOTE: THIS SOFTWARE CAN DAMAGE YOUR WII CONSOLE. USE IT AT YOUR OWN RISK.




Download-patch-install any IOS! :)
----------------------------------
Dop-IOS is a very quick modification to tona's shop installer. It allows
you to download any IOS and apply the trucha bug patch. It also can apply
the ES_Identify patch to IOS36.

This software will be useful for those with modchip who want 4.x features
and still want trucha games on disc channel.
Pikmin 2 (and other newer games like Punch Out) have 3.4 update. If you
update with the disc or by internet, it updates IOS to their newest
versions (trucha fixed).

Usage:
*Make sure you have a cIOS installed on 249
*Update to 3.4 or 4.0 (through game disc)
*Run Dop-IOS
*Dop IOS60 if you are now on 4.x, or IOS50 if you are on 3.4
*Dop IOS36 (for Smash Bros. Brawl and other Nintendo games)
*Dop IOS21 (for third-party games like No More Heroes or Dragon Ball Z Tenkaichi 3)

Now newest games will not ask for update and you will be able to play trucha
games on your 3.4/4.x!



NOTE: If you updated through Waninkoko's method this won't work and Pikmin
2 will still ask you for an update. You must update through Wii game disc
in order to get latest IOS versions.
Updating trough internet will update you to 4.2, and you will lose access
to homebrew (as 29th September 2009).


Version 2 features
------------------
Dop-IOS v2 now can download also older versions of any IOS.

A button     - Downloads latest version in Nintendo servers of selected IOS
Minus button - Downloads older version (with trucha bug if possible) of selected IOS

It also has a protection and it doesn't allow to install latest stub IOSes:
4, 10, 11, 16, 20, 30, 50 and 51. You can still install older versions if you want
(and if possible), but any update (internet or disc) will replace them with the
unused stubs.


Version 3 features
------------------
Dop-IOS v3 now patches ES_Identify too! Thanks to Scarfish code.
Now any downloaded IOS is copied to SD. Next time Dop-IOS will use these files
instead of downloading them again. This will be helpful to users without internet.
SD backup code taken from Hermes' cIOS installer.

IOS60 and IOS61 cannot be installed as older versions in order to avoid confusions.


Version 4 features
------------------
It seems that ES_Identify patch can be buggy in other IOS than 36. So now Dop-IOS
is able to apply this patch only on IOS36.
SD files now are stored on sd:/00000001 and they can be used in other applications.
Now Dop-IOS v4 shows your installed IOS versions!


Version 5 features
------------------
Fixed a bug introduced in v3 that let you install stub IOSes.


Version 6 features
------------------
Added support for IOS57.
I cleaned code a bit.


Version 7 features
------------------
Fixed 'IOS62' bug.
Added IOS56 (WiiSpeak channel users only).
Added short description to IOS selection.


Version 8 features
------------------
Updated to 4.2 new IOS
Added GC pad support



This readme file was written on September 2009, latest version of Wii firmware was 4.2.
Be careful, a new firmware version could turn Dop-IOS into a dangerous application.